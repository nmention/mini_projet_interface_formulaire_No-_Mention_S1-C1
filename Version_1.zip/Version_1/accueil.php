<!DOCTYPE html>
<html lang="fr">
<head>
	<title>accueil</title>
	<meta charset="utf-8">
</head>
<body>
	Vous consulter la page d'accueil
	<br>
	<a href="rechercheVoyage.php">rechercher un voyage</a>
	<p>
        <!-- On vérifie que tous les champs sont définis -->
		<?php if (isset($_POST['nom']) && isset($_POST['telephone']) && isset($_POST['type_voyage']) && isset($_POST['depart_voyage']) && isset($_POST['fin_voyage']))
		{
			$nom = $_POST['nom'];
			$telephone = $_POST['telephone'];
			$type_voyage = $_POST['type_voyage'];
			$depart_voyage = $_POST['depart_voyage'];
			$fin_voyage = $_POST['fin_voyage'];

			// Affichage d'un résumé des informations dans le formulaire
		 echo "<div>Monsieur ".$nom.", votre demande concernant ".$type_voyage." a bien été prise en compte entre le ".$depart_voyage." et le ".$fin_voyage.", un conseiller vous recontactera au ".$telephone."</div>";
	  }?>
	</p>
</body>
</html>
