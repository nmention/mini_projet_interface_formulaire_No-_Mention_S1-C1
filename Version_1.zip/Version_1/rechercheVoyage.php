<!DOCTYPE html>
<html lang="fr">
<head>
	<title>Recherche de voyage</title>
	<meta charset="utf-8">
</head>
<body>
    <!-- Formulaire qui contient les données utilisateur -->
	<form method="post" action="accueil.php">
		<fieldset>
			<label>nom :</label>
			<input type="text" name="nom">
			<br>
			<label>numéro de téléphone: </label>
			<input type="text" name="telephone">
			<br>
			<label>date de départ: </label>
            <!-- On vérifie que la date correspond au pattern -->
			<input type="text" name="depart_voyage" pattern="^[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}$">
			<br>
			<label>date de fin: </label>
			<input type="text" name="fin_voyage" pattern="^[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}$">
			<br>
			<label>type de voyage: </label>
			<input type="text" name="type_voyage">
			<br>
            <!-- Bouton de soumission des informations -->
			<input type="submit" name="soumettre" value="Valider">
		</fieldset>
	</form>
</body>
</html>
