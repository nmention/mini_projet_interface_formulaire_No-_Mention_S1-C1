<!DOCTYPE html>
<?php

// On initialise erreurs
$erreurs = [];

// On vérifie que tous les champs sont définis et valides
if (isset($_POST['nom'])) {
    $donnees['nom'] = htmlentities($_POST['nom']);
    if (!preg_match("/[A-Za-z]{2,}/", $donnees['nom']))
        $erreurs['nom'] = 'Le nom est composé au minimum de deux lettres';
}
if (isset($_POST['type_voyage'])) {
    $donnees['type_voyage'] = htmlentities($_POST['type_voyage']);
    if (!preg_match("/[A-Za-z]{2,}/", $donnees['type_voyage']))
        $erreurs['type_voyage'] = 'le type de voyage est composé au minimum de deux lettres';
}
if (isset($_POST['telephone'])) {
    $donnees['telephone'] = htmlentities($_POST['telephone']);
    // On vérifie le format des infos entrées
    if (!preg_match("/0[0-9]{9}/", $donnees['telephone']))
        $erreurs['telephone'] = 'Le format du numéro de téléphone est invalide';
}

if (isset($_POST['depart_voyage'])) {
    $donnees['depart_voyage'] = htmlentities($_POST['depart_voyage']);

    // Si date incorrect, la fonction echoDateError ajoute une erreur
    echoDateError(isValidDateTime($donnees['depart_voyage']), 'depart_voyage', $erreurs);
}
if (isset($_POST['fin_voyage'])) {
    $donnees['fin_voyage'] = htmlentities($_POST['fin_voyage']);
    echoDateError(isValidDateTime($donnees['fin_voyage']), 'fin_voyage', $erreurs);
}


// On vérifie le pattern de la date, et on retourne un int dépendant de la situation rencontrée
function isValidDateTime($maDate)
{
    if (preg_match("/^([0-9]{1,2})-([0-9]{1,2})-([0-9]{4})$/", $maDate, $matches)) {
        if (checkdate($matches[2], $matches[1], $matches[3])) {
            // OK : 0
            return 0;
        } else {
            // Date invalide : -1
            return -1;
        }
    } else {
        // Format invalide : -2
        return -2;
    }
}

// On ajoute au tableau erreurs le message correspondant au numéro d'erreur donnée par isValidDateTime
function echoDateError($value, $nomErreur, &$erreurs)
{
  switch ($value) {
      case -1:
          $erreurs[$nomErreur] = "La date est invalide";
          break;
      case -2:
          $erreurs[$nomErreur] = "Le format jj-mm-aaaa n'est pas respecté";
          break;
  }
}

?>
<html lang="fr">
<head>
    <title>Recherche de voyage</title>
    <meta charset="utf-8">
</head>
<body>
<!-- Si les données sont correctes et pas d'erreurs on cache le formulaire -->
<form method="post" action="rechercheVoyage.php"<?php if (isset($donnees) && empty($erreurs)) echo "hidden";?> >
    <fieldset>
        <label>nom :</label>
        <!-- En cas d'erreur, les données du formulaire sont laissées intactes -->
        <input type="text" name="nom" value="<?php if (isset($donnees['nom'])) echo $donnees['nom']; ?>">
        <?php if (isset($erreurs['nom'])) echo $erreurs['nom']; ?>
        <br>
        <label>numéro de téléphone: </label>
        <input type="text" name="telephone" value="<?php if (isset($donnees['telephone'])) echo $donnees['telephone']; ?>">
        <?php if (isset($erreurs['telephone'])) echo $erreurs['telephone']; ?>
        <br>
        <label>date de départ: </label>
        <input type="text" name="depart_voyage" value="<?php if (isset($_POST['depart_voyage'])) echo $_POST['depart_voyage'] ?>">
        <?php if (isset($erreurs['depart_voyage'])) echo $erreurs['depart_voyage']; ?>

        <br>
        <label>date de fin: </label>
        <input type="text" name="fin_voyage" value="<?php if (isset($_POST['fin_voyage'])) echo $_POST['fin_voyage'] ?>" >
        <?php if (isset($erreurs['fin_voyage'])) echo $erreurs['fin_voyage']; ?>

        <br>
        <label>type de voyage: </label>
        <input type="text" name="type_voyage"
               value="<?php if (isset($donnees['type_voyage'])) echo $donnees['type_voyage']; ?>">
        <?php if (isset($erreurs['type_voyage'])) echo $erreurs['type_voyage']; ?>
        <br>
        <input type="submit" name="soumettre" value="Valider">
    </fieldset>
</form>
<!-- Si les données sont correctes et pas d'erreurs, on affiche un résumé et un lien de redirection  -->
<?php if (isset($donnees) && empty($erreurs)) {
    echo "<div>Monsieur " . $donnees['nom'] . ", votre demande concernant " . $donnees['type_voyage'] . " a bien été prise en compte entre le " . $donnees['depart_voyage'] . " et le " . $donnees['fin_voyage'] . ", un conseiller vous recontactera au " . $donnees['telephone'] . "." . "</div>";
    echo "<a href='accueil.php'>Retour vers l'accueil</a>";
}
?>
</body>
</html>
