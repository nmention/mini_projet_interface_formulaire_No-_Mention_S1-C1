<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Accueil</title>
    <meta charset="utf-8">
</head>
<body>
Vous consultez la page d'accueil
<br>
<!-- Rediriger vers le champs de saisie des informations -->
<a href="rechercheVoyage.php">Rechercher un voyage</a>
<p>
</p>
</body>
</html>